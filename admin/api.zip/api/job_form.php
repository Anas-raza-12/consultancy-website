<?php
// insert_contact.php

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

// Database connection
require "include/db_conn.php";

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $data = json_decode(file_get_contents("php://input"), true);

    // Validate the data
    $required_fields = ['name', 'email', 'phone', 'age', 'religion', 'gender', 'dob', 'cv', 'cover_letter', 'identity_card', 'current_status', 'job_type', 'address', 'country', 'city', 'university', 'degree', 'deg_start', 'deg_end', 'deg_ongoing', 'linkedin', 'twitter', 'facebook', 'github', 'pre_work_title', 'company_name', 'pre_work_sdate', 'pre_work_edate', 'apply_position'];

        $name = $conn->real_escape_string($data['name']);
        $email = $conn->real_escape_string($data['email']);
        $phone = $conn->real_escape_string($data['phone']);
        $age = $conn->real_escape_string($data['age']);
        $religion = $conn->real_escape_string($data['religion']);
        $gender = $conn->real_escape_string($data['gender']);
        $dob = $conn->real_escape_string($data['dob']);
        $cv = $conn->real_escape_string($data['cv']);
        $cover_letter = $conn->real_escape_string($data['cover_letter']);
        $identity_card = $conn->real_escape_string($data['identity_card']);
        $current_status = $conn->real_escape_string($data['current_status']);
        $job_type = $conn->real_escape_string($data['job_type']);
        $address = $conn->real_escape_string($data['address']);
        $country = $conn->real_escape_string($data['country']);
        $city = $conn->real_escape_string($data['city']);
        $university = $conn->real_escape_string($data['university']);
        $degree = $conn->real_escape_string($data['degree']);
        $deg_start = $conn->real_escape_string($data['deg_start']);
        $deg_end = $conn->real_escape_string($data['deg_end']);
        $deg_ongoing = $conn->real_escape_string($data['deg_ongoing']);
        $linkedin = $conn->real_escape_string($data['linkedin']);
        $twitter = $conn->real_escape_string($data['twitter']);
        $facebook = $conn->real_escape_string($data['facebook']);
        $github = $conn->real_escape_string($data['github']);
        $pre_work_title = $conn->real_escape_string($data['pre_work_title']);
        $company_name = $conn->real_escape_string($data['company_name']);
        $pre_work_sdate = $conn->real_escape_string($data['pre_work_sdate']);
        $pre_work_edate = $conn->real_escape_string($data['pre_work_edate']);
        $apply_position = $conn->real_escape_string($data['apply_position']);

        // Insert query
        $sql = "INSERT INTO job_form_details (name, email, phone, age, religion, gender, dob, cv, cover_letter, identity_card, current_status, job_type, address, country, city, university, degree, deg_start, deg_end, deg_ongoing, linkedin, twitter, facebook, github, pre_work_title, company_name, pre_work_sdate, pre_work_edate, apply_position) VALUES ('$name', '$email', '$phone', '$age', '$religion', '$gender', '$dob', '$cv', '$cover_letter', '$identity_card', '$current_status', '$job_type', '$address', '$country', '$city', '$university', '$degree', '$deg_start', '$deg_end', '$deg_ongoing', '$linkedin', '$twitter', '$facebook', '$github', '$pre_work_title', '$company_name', '$pre_work_sdate', '$pre_work_edate', '$apply_position')";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(['status' => 'success', 'message' => 'Job form details inserted successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to insert job form details.']);
        }
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Fetch data
    $sql = "SELECT * FROM job_form_details";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode(['status' => 'success', 'data' => $data]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No data found.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}

$targetDir = "uploads/";
$targetFile = $targetDir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

// Check if file already exists
if (file_exists($targetFile)) {
    echo json_encode(["message" => "Sorry, file already exists."]);
    $uploadOk = 0;
}

// Check file size (limit to 5MB)
if ($_FILES["file"]["size"] > 5000000) {
    echo json_encode(["message" => "Sorry, your file is too large."]);
    $uploadOk = 0;
}

// Allow certain file formats
$allowedFormats = ["jpg", "png", "jpeg", "gif", "pdf", "docx"];
if (!in_array($fileType, $allowedFormats)) {
    echo json_encode(["message" => "Sorry, only JPG, JPEG, PNG, GIF, PDF & DOCX files are allowed."]);
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo json_encode(["message" => "Sorry, your file was not uploaded."]);
// If everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
        // Save file link to MySQL database
        $servername = "localhost";
        $username = "username";
        $password = "password";
        $dbname = "database";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $fileLink = $targetFile;
        $sql = "INSERT INTO files (file_link) VALUES ('$fileLink')";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["message" => "The file has been uploaded and saved in the database."]);
        } else {
            echo json_encode(["message" => "Error saving file link to database: " . $conn->error]);
        }

        $conn->close();
    } else {
        echo json_encode(["message" => "Sorry, there was an error uploading your file."]);
    }
}

?>
